package com.tata.cds.dao;

import com.tata.cds.models.CD;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CDdao {
    Scanner input=new Scanner(System.in);
    public List<CD> getCdData(){
        List<CD> CdArray = new ArrayList<>();
        CD cd = null;
        for(int i=0;i<3;i++)
        {
            cd=new CD();
            System.out.println("Enter Song Title for song"+(i+1)+" :");
            cd.setTitle(input.next());
            System.out.println("Enter Singer Name for song"+(i+1)+" :");
            cd.setSinger(input.next());

            CdArray.add(cd);
        }
        return CdArray;
    }
}