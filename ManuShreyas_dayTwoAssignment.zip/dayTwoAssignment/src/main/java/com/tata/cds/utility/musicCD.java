package com.tata.cds.utility;


import com.tata.cds.business.SortBasedOnSinger;
import com.tata.cds.dao.CDdao;
import com.tata.cds.models.CD;

import java.util.Collections;
import java.util.List;

public class musicCD {
    public static void main(String[] args){
        CDdao cdDao= (CDdao) new CDdao();
        List<CD> cdd=cdDao.getCdData();
        System.out.println("Sorting based on Singer's name....");
        Collections.sort(cdd,new SortBasedOnSinger());
        for(CD cd:cdd)
        {
            System.out.println(cd.getTitle()+"     "+cd.getSinger());
        }
    }
}