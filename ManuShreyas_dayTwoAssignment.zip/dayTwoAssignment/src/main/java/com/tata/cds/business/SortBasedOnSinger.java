package com.tata.cds.business;

import com.tata.cds.models.CD;

import java.util.Comparator;

public class SortBasedOnSinger implements Comparator<CD>{
    @Override
    public int compare(CD c1, CD c2) {
        return c1.getSinger().compareTo(c2.getSinger());
    }
}