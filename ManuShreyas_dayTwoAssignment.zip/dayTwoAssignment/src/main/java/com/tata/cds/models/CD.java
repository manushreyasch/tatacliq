package com.tata.cds.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CD {
        private String title;
        private String singer;
}
