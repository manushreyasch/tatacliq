package com.tata.cds;

        import com.tata.cds.models.CD;
        import org.junit.jupiter.api.AfterEach;
        import org.junit.jupiter.api.BeforeEach;
        import org.junit.jupiter.api.DisplayName;
        import org.junit.jupiter.api.Test;

        import java.util.Random;

        import static org.junit.jupiter.api.Assertions.assertNotEquals;
        import static org.junit.jupiter.api.Assertions.assertThrows;

public class CDsTest {
    private CD cdOne, cdTwo, cdThree;

    @BeforeEach
    public void getInstance(){
        cdOne =new CD();
        cdOne.setSinger(""+new Random().nextInt(500));
        cdOne.setTitle(""+new Random().nextInt(500));

        cdTwo =new CD();
        cdTwo.setSinger(""+new Random().nextInt(500));
        cdTwo.setTitle(""+new Random().nextInt(500));
    }

    @Test
    @DisplayName("Test to not have Singer as null element")
    public void testSingerNotNull(){
        assertNotEquals("", cdOne.getSinger());
    }

    @Test
    @DisplayName("Test to not have Title as null element")
    public void testTitleNotNull(){

        assertNotEquals("", cdTwo.getTitle());
    }


    @Test()
    public void negativeTestForCDInstance(){
        assertThrows(NullPointerException.class,
                ()->{
                    cdThree.getSinger();
                    cdThree.getTitle();
                });
    }

    @AfterEach
    public void testUnReferenceInstance(){
        cdOne =null;
        cdTwo =null;
        cdThree =null;
    }
}