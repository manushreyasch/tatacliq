import java.util.Scanner;

public class shopkeeper {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);  //for input
        System.out.println("Enter product Number to order: ");
        int productNo = input.nextInt();

        System.out.println("Enter quantity: ");
        int quantity = input.nextInt();

        float totalPrice = totalCostCalculator.calc(productNo,quantity);

        if(totalPrice == -1)
            System.out.println("Enter valid details....");
        else
            System.out.println("Total price : "+ totalPrice);
    }
}