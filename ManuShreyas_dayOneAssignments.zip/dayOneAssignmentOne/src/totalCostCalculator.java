public class totalCostCalculator{
    static float costProductOne = 22.50f;
    static float costProductTwo = 44.50f;
    static float costProductThree = 9.98f;

    static float calc(int productNo,int quantityOrdered){
        switch (productNo){
            case 1: return (costProductOne * quantityOrdered);
            case 2: return (costProductTwo * quantityOrdered);
            case 3: return (costProductThree * quantityOrdered);

            default: return -1f;
        }
    }
}
