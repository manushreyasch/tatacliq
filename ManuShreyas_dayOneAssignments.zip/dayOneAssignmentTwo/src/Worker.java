public class Worker {
    protected String name;
    protected float salaryRate;

    Worker(String name, float salaryRate){  // constructor
        this.name = name;
        this.salaryRate = salaryRate;
    }
   //setter
    public void setSalaryRate(float salaryRate){
        this.salaryRate = salaryRate;
    }
    //setter
    public void setName(String name){
        this.name = name;
    }

    float payment(int hours){
        return salaryRate*hours;
    }
}
