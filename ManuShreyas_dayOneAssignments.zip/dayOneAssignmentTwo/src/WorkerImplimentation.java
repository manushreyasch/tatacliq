public class WorkerImplimentation {

    public static void main(String[] args){
        DailyWorker dailyWorker = new DailyWorker("Worker1",75);
        SalariedWorker salariedWorker = new SalariedWorker("Worker2",60);

        System.out.println(dailyWorker.name+"'s weekly salary for 50 hours is : "+dailyWorker.payment(35));
        System.out.println(salariedWorker.name+"'s weekly salary for one week is : "+salariedWorker.payment());

    }
}
