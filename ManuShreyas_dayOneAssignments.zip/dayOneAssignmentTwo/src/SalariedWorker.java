public class SalariedWorker extends Worker {

    SalariedWorker(String name, float salaryRate) {
        super(name, salaryRate);
    }

    float payment(){
            return super.payment(40); //polymorfic function
        }
}

