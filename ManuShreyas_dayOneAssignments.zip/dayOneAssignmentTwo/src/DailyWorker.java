public class DailyWorker extends Worker{
    DailyWorker(String name, float salaryRate) {
        super(name, salaryRate);
    }

    @Override
    float payment(int hoursWorked){
        return super.payment(hoursWorked);
    }
}
