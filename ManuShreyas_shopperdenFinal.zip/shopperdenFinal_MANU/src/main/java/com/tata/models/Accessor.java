package com.tata.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Accessor {
    private int AccessorId;
    private String AccessorName;
    private String email;
    private String password;
    private String address;
    private long phone;
    private AccessorRole accessorRole;
    private ShoppingCart shoppingCart;
}
