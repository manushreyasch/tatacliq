package com.tata.models;

public enum AccessorRole {
    ADMIN,CUSTOMER
}
