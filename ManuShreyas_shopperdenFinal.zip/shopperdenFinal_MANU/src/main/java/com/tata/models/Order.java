package com.tata.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Order {
    private int orderId;
    private LocalDate dateOfOrderPlaced;
    private ShoppingCart shoppingCart;
    private Accessor accessor;
    private LocalDate dateOfDelivery;
    private int totalAmount;
    private PaymentMode paymentMode;
    private boolean paid;
}
