package com.tata.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Product {
    private int pid;
    private String pname;
    private LocalDate date;
    private int price;
    private int totalQuantity;
    private String productDescription;
    private Category category;
}
