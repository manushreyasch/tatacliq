package com.tata.models;

public enum PaymentMode {
    CARD,UPI,COD
}
