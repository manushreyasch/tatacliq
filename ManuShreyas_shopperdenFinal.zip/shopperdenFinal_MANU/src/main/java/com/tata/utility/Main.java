package com.tata.utility;

import java.sql.SQLException;
/*
import com.tata.model.*;
import com.tata.helper.*;
import com.tata.dao.*;

 */

public class Main {
    public static void main(String[] args) throws SQLException {

        //user app (utility) would be written here
    }
}