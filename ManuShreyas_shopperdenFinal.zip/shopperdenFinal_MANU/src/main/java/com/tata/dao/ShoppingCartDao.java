package com.tata.dao;

import com.tata.models.Accessor;
import com.tata.models.ShoppingCart;

import java.sql.SQLException;

public interface ShoppingCartDao {
    public void addCart(Accessor accessor) throws SQLException;
    public void deleteCartByUid(int uid) throws SQLException;
    public ShoppingCart getCartByUser(Accessor accessor) throws SQLException;
    public ShoppingCart getCartById(int cartId) throws SQLException;
}
