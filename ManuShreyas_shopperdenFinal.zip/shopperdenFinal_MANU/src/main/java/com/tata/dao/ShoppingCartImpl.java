package com.tata.dao;

import com.tata.helper.postgresConnHelper;
import com.tata.models.ShoppingCart;
import com.tata.models.Accessor;

import java.sql.*;
import java.util.ResourceBundle;

public class ShoppingCartImpl implements ShoppingCartDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement acart,selcartbyuid,deletecart,selcartbycartid;
    private ResultSet resultSet;

    public ShoppingCartImpl() {
        conn= postgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }


    @Override
    public void addCart(Accessor accessor) throws SQLException {
        String addcart=resourceBundle.getString("addShoppingCart");
        acart = conn.prepareStatement(addcart);
        acart.setInt(1, accessor.getShoppingCart().getCartId());
        acart.setInt(2, accessor.getAccessorId());
        acart.executeUpdate();
    }

    @Override
    public void deleteCartByUid(int uid) throws SQLException {
        String query = resourceBundle.getString("deleteCartByAid");
        deletecart = conn.prepareStatement(query);
        deletecart.setInt(1,uid);
        deletecart.executeUpdate();
    }

    @Override
    public ShoppingCart getCartByUser(Accessor accessor) throws SQLException {
        int uid = accessor.getAccessorId();
        String query = resourceBundle.getString("selectShoppingCartbyAid");
        selcartbyuid=conn.prepareStatement(query);
        selcartbyuid.setInt(1,uid);
        resultSet=selcartbyuid.executeQuery();
        ShoppingCart cart = new ShoppingCart();
        while (resultSet.next()) {
            cart.setCartId(resultSet.getInt(1));
            cart.setAccessor(accessor);
        }
        return cart;
    }

    @Override
    public ShoppingCart getCartById(int cartId) throws SQLException {
        ShoppingCart cart = null;
        CustomerDao customerDao = new CustomerImpl();
        String query = resourceBundle.getString("selectCartByCartId");
        selcartbycartid=conn.prepareStatement(query);
        selcartbycartid.setInt(1,cartId);
        resultSet=selcartbycartid.executeQuery();
        while (resultSet.next()) {
            cart = new ShoppingCart();
            cart.setCartId(resultSet.getInt(1));
            cart.setAccessor(customerDao.getCustomerById(resultSet.getInt(2)));
        }
        return cart;
    }
}
