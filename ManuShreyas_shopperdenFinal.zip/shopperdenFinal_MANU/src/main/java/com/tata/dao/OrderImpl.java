package com.tata.dao;

import com.tata.helper.postgresConnHelper;
import com.tata.models.Order;
import com.tata.models.PaymentMode;
import com.tata.models.Accessor;

import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;

public class OrderImpl implements OrderDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement aorder,canorder,confirmord,selorderbyuid;
    private ResultSet resultSet;

    public OrderImpl() {
        conn= postgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void placeOrder(Accessor accessor, Order order) throws SQLException {
        String addorder=resourceBundle.getString("addOrder");
        aorder=conn.prepareStatement(addorder);
        aorder.setInt(1,order.getOrderId());
        aorder.setDate(2, Date.valueOf(order.getDateOfOrderPlaced()));
        aorder.setInt(3,order.getShoppingCart().getCartId());
        aorder.setInt(4, accessor.getAccessorId());
        aorder.setInt(5,order.getTotalAmount());
        aorder.setBoolean(6,order.isPaid());
        aorder.executeUpdate();
    }

    @Override
    public void confirmOrder(Accessor accessor, int OrderId, String mode) throws SQLException {
        String confirmOrder = resourceBundle.getString("confirmOrder");
        confirmord = conn.prepareStatement(confirmOrder);
        confirmord.setDate(1,Date.valueOf(LocalDate.now().plus(2+new Random().nextInt(5), ChronoUnit.DAYS)));
        confirmord.setString(2,mode);
        confirmord.setBoolean(3,true);
        confirmord.setInt(4, OrderId);
        confirmord.executeUpdate();

        ShoppingCartProductsDao shoppingCartProductsDao = new ShoppingCartProductsImpl();
    }

    @Override
    public void cancelOrder(int orderId) throws SQLException {
        String query = resourceBundle.getString("cancelOrder");
        canorder = conn.prepareStatement(query);
        canorder.setInt(1,orderId);
        canorder.executeUpdate();
    }

    @Override
    public List<Order> viewAllOrder(int userId) throws SQLException {
        ShoppingCartDao shoppingCartDao = new ShoppingCartImpl();
        CustomerDao customerDao = new CustomerImpl();
        List<Order> orderList = new ArrayList<Order>();
        Order order = null;
        String mode = null;
        String query = resourceBundle.getString("selectAllOrderByAid");
        selorderbyuid = conn.prepareStatement(query);
        selorderbyuid.setInt(1,userId);
        resultSet = selorderbyuid.executeQuery();
        while(resultSet.next()){
            order = new Order();
            order.setOrderId(resultSet.getInt(1));
            order.setDateOfOrderPlaced(resultSet.getDate(2).toLocalDate());
            order.setShoppingCart(shoppingCartDao.getCartById(resultSet.getInt(3)));
            order.setAccessor(customerDao.getCustomerById(resultSet.getInt(4)));
            order.setDateOfDelivery(resultSet.getDate(5).toLocalDate());
            order.setTotalAmount(resultSet.getInt(6));
            mode = resultSet.getString(7);
            if(mode.equals("CARD")){
                order.setPaymentMode(PaymentMode.CARD);
            } else if(mode.equals("UPI")){
                order.setPaymentMode(PaymentMode.UPI);
            } else {
                order.setPaymentMode(PaymentMode.COD);
            }
            order.setPaid(resultSet.getBoolean(8));
            orderList.add(order);
        }
        return orderList;
    }

}
