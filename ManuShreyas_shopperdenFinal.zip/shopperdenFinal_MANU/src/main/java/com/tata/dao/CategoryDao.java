package com.tata.dao;

import com.tata.models.Category;

import java.sql.SQLException;
import java.util.List;

public interface CategoryDao {
    void addCategory(Category category) throws SQLException;
    List<Category> getAllCategories() throws SQLException;
    Category getCategoryById(int categoryId) throws SQLException;
    void updateCategory(int cid,String catname) throws SQLException;
    public void deleteCategory(int cid) throws SQLException;
}
