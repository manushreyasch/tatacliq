package com.tata.dao;

import com.tata.models.Category;
import com.tata.helper.postgresConnHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CategoryImpl implements CategoryDao {
    private ResourceBundle resourceBundle;
    private Connection connection;
    private PreparedStatement addCategory, selectById, updateCategory, deleteCategory;
    private Statement statement;
    private ResultSet resultSet;

    public CategoryImpl() {
        connection = postgresConnHelper.getConnection();
        if(connection ==null) {
            System.out.println("Problem in Connecting!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void addCategory(Category category) throws SQLException {
        String addCategory = resourceBundle.getString("addCategory");
        this.addCategory = connection.prepareStatement(addCategory);
        this.addCategory.setInt(1, category.getCid());
        this.addCategory.setString(2, category.getCname());
        this.addCategory.executeUpdate();
    }

    @Override
    public List<Category> getAllCategories() throws SQLException {
        String query=resourceBundle.getString("selectAllCategory");;
        List<Category> categoryList=new ArrayList<Category>();
        Category category=null;
        statement= connection.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next()){
            category=new Category();
            category.setCid(resultSet.getInt(1));
            category.setCname(resultSet.getString(2));
            categoryList.add(category);
        }
        return categoryList;
    }

    @Override
    public Category getCategoryById(int categoryId) throws SQLException {
        Category category = null;
        String query = resourceBundle.getString("selectCategoryById");
        selectById = connection.prepareStatement(query);
        selectById.setInt(1,categoryId);
        resultSet= selectById.executeQuery();
        while(resultSet.next()) {
            category = new Category();
            category.setCid(resultSet.getInt(1));
            category.setCname(resultSet.getString(2));
        }
        return category;
    }

    @Override
    public void updateCategory(int cid, String catname) throws SQLException {
        String query = resourceBundle.getString("updateCategory");
        updateCategory = connection.prepareStatement(query);
        updateCategory.setString(1,catname);
        updateCategory.setInt(2,cid);
        updateCategory.executeUpdate();
    }

    @Override
    public void deleteCategory(int cid) throws SQLException {
        String query = resourceBundle.getString("deleteCategory");
        deleteCategory = connection.prepareStatement(query);
        deleteCategory.setInt(1,cid);
        deleteCategory.executeUpdate();
    }
}
