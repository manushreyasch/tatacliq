package com.tata.dao;

import java.sql.SQLException;

public interface LoginDao {
    public boolean validateAccessorId(int id) throws SQLException;
    public boolean validatePassword(int id, String pass) throws SQLException;
    public boolean validateAdminAccess(int id) throws SQLException;
}
