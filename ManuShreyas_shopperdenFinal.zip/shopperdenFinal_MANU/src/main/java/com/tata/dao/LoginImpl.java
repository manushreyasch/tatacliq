package com.tata.dao;

import com.tata.helper.postgresConnHelper;

import java.sql.*;
import java.util.ResourceBundle;

public class LoginImpl implements LoginDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement validateAid, validatePassword, validateAdmin;
    private ResultSet resultSet;

    public LoginImpl() {
        conn= postgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public boolean validateAccessorId(int id) throws SQLException {
        String query = resourceBundle.getString("ValidateUserId");
        validateAid = conn.prepareStatement(query);
        validateAid.setInt(1,id);
        resultSet = validateAid.executeQuery();
        if(resultSet.next()){
            return true;
        }
        return false;
    }

    @Override
    public boolean validatePassword(int id, String pass) throws SQLException {
        String query = resourceBundle.getString("ValidatePassword");
        validatePassword = conn.prepareStatement(query);
        validatePassword.setInt(1,id);
        resultSet = validatePassword.executeQuery();
        if (resultSet.next() && resultSet.getString(1).equals(pass)){
            return true;
        }
        return false;
    }

    @Override
    public boolean validateAdminAccess(int id) throws SQLException {
        String query = resourceBundle.getString("validateAdmin");
        validateAdmin = conn.prepareStatement(query);
        validateAdmin.setInt(1,id);
        resultSet = validateAdmin.executeQuery();
        if(resultSet.next()){
            if (resultSet.getInt(1)==1){
                return true;
            } else {
                return false;
            }
        }
        return false;
    }
}
