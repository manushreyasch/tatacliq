package com.tata.dao;

import com.tata.helper.postgresConnHelper;
import com.tata.models.Accessor;

import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class ShoppingCartProductsImpl implements ShoppingCartProductsDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement addpinc,delpinc,updqinc;

    public ShoppingCartProductsImpl() {
        conn= postgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void addProducts(Accessor accessor, int productId, int quantity) throws SQLException {
        String addPInC=resourceBundle.getString("addProductInCart");
        addpinc=conn.prepareStatement(addPInC);
        addpinc.setInt(1, accessor.getShoppingCart().getCartId());
        addpinc.setInt(2,productId);
        addpinc.setDate(3,Date.valueOf(LocalDate.now()));
        addpinc.setInt(4,quantity);
        addpinc.executeUpdate();
    }

    @Override
    public void deleteProducts(Accessor accessor, int productId) throws SQLException {
        String deletePInC=resourceBundle.getString("deleteProductInCart");
        delpinc=conn.prepareStatement(deletePInC);
        delpinc.setInt(1, accessor.getShoppingCart().getCartId());
        delpinc.setInt(2,productId);
        delpinc.executeUpdate();
    }

    @Override
    public void updateQuantity(Accessor accessor, int productId, int quantity) throws SQLException {
        String updateQInC=resourceBundle.getString("updateQuantityInCart");
        updqinc=conn.prepareStatement(updateQInC);
        updqinc.setInt(1,quantity);
        updqinc.setInt(2, accessor.getShoppingCart().getCartId());
        updqinc.setInt(3,productId);
        updqinc.executeUpdate();
    }


}
