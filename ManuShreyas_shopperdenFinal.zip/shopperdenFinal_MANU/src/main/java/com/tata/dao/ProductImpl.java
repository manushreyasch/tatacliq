package com.tata.dao;

import com.tata.helper.postgresConnHelper;
import com.tata.models.Category;
import com.tata.models.Product;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class ProductImpl implements com.tata.dao.ProductDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement addp,updatepquan
            ,updatepprice,updatepdesc,deletep,selpbyid;
    private Statement statement;
    private ResultSet resultSet;

    public ProductImpl() {
        conn= postgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public List<Product> getAllProducts() throws SQLException {
        List<Product>productList=new ArrayList<Product>();
        Product product= null;
        String query = resourceBundle.getString("selectAllProduct");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next()) {
            product = new Product();
            product.setPid(resultSet.getInt(1));
            product.setPname(resultSet.getString(2));
            product.setDate(resultSet.getDate(3).toLocalDate());
            product.setPrice(resultSet.getInt(4));
            product.setTotalQuantity(resultSet.getInt(5));

            com.tata.dao.CategoryDao categoryDao = new com.tata.dao.CategoryImpl();
            Category category=categoryDao.getCategoryById(resultSet.getInt(7));
            product.setCategory(category);

            productList.add(product);
        }
        return productList;
    }

    @Override
    public Product getProductById(int pid) throws SQLException {
        Product product = null;
        String query = resourceBundle.getString("selectProductById");
        selpbyid = conn.prepareStatement(query);
        selpbyid.setInt(1,pid);
        resultSet=selpbyid.executeQuery();
        while(resultSet.next()) {
            product = new Product();
            product.setPid(resultSet.getInt(1));
            product.setPname(resultSet.getString(2));
            product.setDate(resultSet.getDate(3).toLocalDate());
            product.setPrice(resultSet.getInt(4));
            product.setTotalQuantity(resultSet.getInt(5));

            com.tata.dao.CategoryDao categoryDao = new com.tata.dao.CategoryImpl();
            Category category=categoryDao.getCategoryById(resultSet.getInt(7));
            product.setCategory(category);
        }
        return product;
    }

    @Override
    public void addProduct(Product product) throws SQLException {
        String addProduct=resourceBundle.getString("addProduct");
        addp=conn.prepareStatement(addProduct);
        addp.setInt(1,product.getPid());
        addp.setString(2,product.getPname());
        addp.setDate(3, Date.valueOf(LocalDate.now()));
        addp.setLong(4,product.getPrice());
        addp.setInt(5,product.getTotalQuantity());
        addp.setInt(7,product.getCategory().getCid());
        addp.executeUpdate();
    }

    @Override
    public void updateProductQuantity(int pid, int quan) throws SQLException {
        String query = resourceBundle.getString("updateProductQuantity");
        updatepquan = conn.prepareStatement(query);
        updatepquan.setInt(1,quan);
        updatepquan.setInt(2,pid);
        updatepquan.executeUpdate();
    }

    @Override
    public void updateProductPrice(int pid, int price) throws SQLException {
        String query = resourceBundle.getString("updateProductPrice");
        updatepprice = conn.prepareStatement(query);
        updatepprice.setInt(1,price);
        updatepprice.setInt(2,pid);
        updatepprice.executeUpdate();
    }

    @Override
    public void updateProductDescription(int pid, String desc) throws SQLException {
        String query = resourceBundle.getString("updateProductDescription");
        updatepdesc = conn.prepareStatement(query);
        updatepdesc.setString(1,desc);
        updatepdesc.setInt(2,pid);
        updatepdesc.executeUpdate();
    }

    @Override
    public void deleteProduct(int pid) throws SQLException {
        String query = resourceBundle.getString("deleteProduct");
        deletep = conn.prepareStatement(query);
        deletep.setInt(1,pid);
        deletep.executeUpdate();
    }
}
