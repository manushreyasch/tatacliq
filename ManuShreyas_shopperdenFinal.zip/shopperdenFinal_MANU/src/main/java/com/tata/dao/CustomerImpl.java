package com.tata.dao;

import com.tata.helper.postgresConnHelper;
import com.tata.models.Accessor;
import com.tata.models.AccessorRole;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CustomerImpl implements CustomerDao {
    private ResourceBundle resourceBundle;
    private Connection connection;
    private PreparedStatement addAccessor, deleteAccessor, updatePassword, updatePhone, selectAid;
    private Statement statement;
    private ResultSet resultSet;

    public CustomerImpl() {
        connection = postgresConnHelper.getConnection();
        if(connection ==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public List<Accessor> getAllCustomer() throws SQLException {
        List<Accessor>userList=new ArrayList<Accessor>();
        Accessor accessor = null;
        String query = resourceBundle.getString("selectAllAceessor");
        statement = connection.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next()) {
            accessor = new Accessor();
            accessor.setAccessorId(resultSet.getInt(1));
            accessor.setAccessorName(resultSet.getString(2));
            accessor.setEmail(resultSet.getString(3));
            accessor.setPassword(resultSet.getString(4));
            accessor.setAddress(resultSet.getString(5));
            accessor.setPhone(resultSet.getLong(6));
            if(resultSet.getInt(7)==1) {
                accessor.setAccessorRole(AccessorRole.ADMIN);
            } else {
                accessor.setAccessorRole(AccessorRole.CUSTOMER);
            }

            ShoppingCartDao shoppingCartDao = new ShoppingCartImpl();
            accessor.setShoppingCart(shoppingCartDao.getCartByUser(accessor));
            userList.add(accessor);
        }
        return userList;
    }

    @Override
    public void addCustomer(Accessor accessor) throws SQLException {
        String adduser=resourceBundle.getString("addAccessor");
        addAccessor = connection.prepareStatement(adduser);
        addAccessor.setInt(1, accessor.getAccessorId());
        addAccessor.setString(2, accessor.getAccessorName());
        addAccessor.setString(3, accessor.getEmail());
        addAccessor.setString(4, accessor.getPassword());
        addAccessor.setString(5, accessor.getAddress());
        addAccessor.setLong(6, accessor.getPhone());
        if(accessor.getAccessorRole().equals(AccessorRole.ADMIN)) {
            addAccessor.setInt(7,1);
        } else {
            addAccessor.setInt(7,2);
        }
        addAccessor.executeUpdate();
        ShoppingCartDao shoppingCartDao = new ShoppingCartImpl();
        shoppingCartDao.addCart(accessor);
    }


    @Override
    public void updateCustomerPass(int customerId, String pass) throws SQLException {
        String query = resourceBundle.getString("updateAccessorPassword");
        updatePassword = connection.prepareStatement(query);
        updatePassword.setString(1,pass);
        updatePassword.setInt(2,customerId);
        updatePassword.executeUpdate();
    }


    @Override
    public void updateCustomerPhone(int userId, long phone) throws SQLException {
        String query = resourceBundle.getString("updateAccessorPhone");
        updatePhone = connection.prepareStatement(query);
        updatePhone.setLong(1,phone);
        updatePhone.setInt(2,userId);
        updatePhone.executeUpdate();
    }

    @Override
    public void deleteCustomer(int userId) throws SQLException {
        ShoppingCartDao shoppingCartDao = new ShoppingCartImpl();
        shoppingCartDao.deleteCartByUid(userId);
        String query = resourceBundle.getString("deleteAccessor");
        deleteAccessor = connection.prepareStatement(query);
        deleteAccessor.setInt(1,userId);
        deleteAccessor.executeUpdate();
    }

    @Override
    public Accessor getCustomerById(int userId) throws SQLException {
        Accessor accessor = null;
        String query = resourceBundle.getString("selectAccessorById");
        selectAid = connection.prepareStatement(query);
        selectAid.setInt(1,userId);
        resultSet= selectAid.executeQuery();
        while(resultSet.next()) {
            accessor = new Accessor();
            accessor.setAccessorId(resultSet.getInt(1));
            accessor.setAccessorName(resultSet.getString(2));
            accessor.setEmail(resultSet.getString(3));
            accessor.setPassword(resultSet.getString(4));
            accessor.setAddress(resultSet.getString(5));
            accessor.setPhone(resultSet.getLong(6));
            if(resultSet.getInt(7)==1) {
                accessor.setAccessorRole(AccessorRole.ADMIN);
            } else {
                accessor.setAccessorRole(AccessorRole.CUSTOMER);
            }
            ShoppingCartDao shoppingCartDao = new ShoppingCartImpl();
            accessor.setShoppingCart(shoppingCartDao.getCartByUser(accessor));
        }
        return accessor;
    }
}
