package com.tata.dao;

import com.tata.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface ProductDao {
    public void addProduct(Product product) throws SQLException;
    public void deleteProduct(int pid) throws SQLException;
    public void updateProductQuantity(int pid,int quan) throws SQLException;
    public void updateProductPrice(int pid,int price) throws SQLException;
    List<Product> getAllProducts() throws SQLException;
    public Product getProductById(int pid) throws SQLException;
    public void updateProductDescription(int pid,String desc) throws SQLException;
}
