package com.tata.dao;

import com.tata.models.Accessor;

import java.sql.SQLException;
import java.util.List;

public interface CustomerDao {
    List<Accessor> getAllCustomer() throws SQLException;
    public void addCustomer(Accessor accessor) throws SQLException;
    public void deleteCustomer(int userId) throws SQLException;
    public void updateCustomerPass(int userId, String pass) throws SQLException;
    public void updateCustomerPhone(int userId, long phone) throws SQLException;
    public Accessor getCustomerById(int userid) throws SQLException;
}
