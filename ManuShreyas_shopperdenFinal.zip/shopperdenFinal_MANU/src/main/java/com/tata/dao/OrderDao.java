package com.tata.dao;

import com.tata.models.Order;
import com.tata.models.Accessor;

import java.sql.SQLException;
import java.util.List;

public interface OrderDao {
    void placeOrder(Accessor accessor, Order order) throws SQLException;
    void confirmOrder(Accessor accessor, int orderId, String mode) throws SQLException;
    void cancelOrder(int orderId) throws SQLException;
    List<Order> viewAllOrder(int userId) throws SQLException;
}
