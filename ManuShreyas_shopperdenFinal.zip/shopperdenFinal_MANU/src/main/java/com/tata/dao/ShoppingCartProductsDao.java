package com.tata.dao;

import com.tata.models.Accessor;

import java.sql.SQLException;

public interface ShoppingCartProductsDao {
    public void addProducts(Accessor accessor, int productId, int quantity) throws SQLException;
    public void deleteProducts(Accessor accessor, int productId) throws SQLException;
    public void updateQuantity(Accessor accessor, int productId, int quantity) throws SQLException;
}
